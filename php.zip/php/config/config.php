<?php
	$glb_servername = "localhost";
	$glb_username = "biscl_ars";
	$glb_password = "ddA0h83%";
	$glb_dbName = "biscleco_ars";
	$glb_tableName = "user";
	
	//admin login details
	$glb_username = "admin";
	$glb_password = "admin";
?>