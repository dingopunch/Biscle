<?php
	define("ERROR_LOG_FILE", "./error.log");
	include "config/config.php";
	
	print_r(getUserInfo());
	
	function getUserInfo () {
		global $glb_tableName;
		$conn = getDBConnection();
		if ($conn !== null) {
			$sql = "SELECT id, userId, firstname, lastname, email, status, username FROM $glb_tableName";
			$result = $conn->query($sql);
			
			$users = array();
			if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					array_push($users,$row);
				}
			}
			
			$conn->close();
			return $users;
		} else {
			error_log(date('[Y-m-d H:i e] '). "Connection failed: in getUserInfo function" . PHP_EOL, 3, ERROR_LOG_FILE);
			return null;
		}
	}
	
	function getDBConnection () {
		global $glb_servername;
		global $glb_username;
		global $glb_password;
		global $glb_dbName;
		
		$conn = mysqli_connect("localhost","biscl_ars","ddA0h83%","biscleco_ars");
		if ($conn->connect_error) {
			error_log(date('[Y-m-d H:i e] '). "Connection failed: " . $conn->connect_error . PHP_EOL, 3, ERROR_LOG_FILE);
			return null;
		} else {
			return $conn;
		}
	}
	
	function insertEntry ($query) {
		$conn = getDBConnection();
		
		if ($conn !== null) {
			if ($conn->query($query) !== TRUE) {
				error_log(date('[Y-m-d H:i e] '). "Error: " . $query . " : " . $conn->error . PHP_EOL, 3, ERROR_LOG_FILE);
			}

			$conn->close();
			
			return true;
		} else {
			error_log(date('[Y-m-d H:i e] '). "Connection failed: in insertEntry function" . PHP_EOL, 3, ERROR_LOG_FILE);
			return false;
		}
	}
?>